﻿using rotatorBugExample.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace rotatorBugExample.ViewModels
{
    public class MainViewModel : AbstractModel
    {
        private bool _clearClickable;
        public bool clearClickable
        {
            get { return _clearClickable; }
            set
            {
                _clearClickable = value;
                OnPropertyChanged("clearClickable");
            }
        }

        private bool _addClickable;
        public bool addClickable
        {
            get { return _addClickable; }
            set
            {
                _addClickable = value;
                OnPropertyChanged("addClickable");
            }
        }

        public ICommand UpdateNumbersCommand { get; private set; }
        public ICommand RemoveFromCollection { get; private set; }
        public ICommand ClearAllCommand { get; private set; }
        public ICommand AddAllCommand { get; private set; }

        private MainModel _model;
        public MainModel model
        {
            get { return _model; }
            set
            {
                _model = value;
                OnPropertyChanged("model");
            }
        }

        public MainViewModel()
        {
            model = new MainModel();

            this.UpdateNumbersCommand = new Command(UpdateNumbers);
            this.RemoveFromCollection = new Command<int>(RemoveNumber);
            this.AddAllCommand = new Command(AddNumbers);
            this.ClearAllCommand = new Command(ClearNumbers);

            Random rand1 = new Random();
            Random rand2 = new Random();
            Random rand3 = new Random();

            for (int i = 0; i < 7; i++)
            {
                model.numbers.Add(new ObservableCollection<NumberModel>()
                {
                    new NumberModel(){ numberInt = rand1.Next(1, 100), backgroundColour = App.colours[rand1.Next(0, App.colours.Length - 1)] },
                    new NumberModel(){ numberInt = rand2.Next(1, 100), backgroundColour = App.colours[rand2.Next(0, App.colours.Length - 1)] },
                    new NumberModel(){ numberInt = rand3.Next(1, 100), backgroundColour = App.colours[rand3.Next(0, App.colours.Length - 1)] },
                });
            }

            addClickable = false;
            clearClickable = true;
        }

        private void RemoveNumber(int number)
        {
            for (int i = 0; i < 7; i++)
            {
                NumberModel toRemove = model.numbers[i].Where(x => x.numberInt == number).FirstOrDefault();
                if (toRemove != null)
                    model.numbers[i].Remove(toRemove);
            }

            int totalItemCount = 0;

            for (int i = 0; i < 7; i++)
            {
                totalItemCount += model.numbers[i].Count;
            }

            if (totalItemCount < 1)
            {
                clearClickable = false;
                addClickable = true;
            }
        }

        private void UpdateNumbers()
        {
            Random rand1 = new Random();
            Random rand2 = new Random();
            Random rand3 = new Random();

            for (int i = 0; i < 7; i++)
            {
                model.numbers[i].Clear();
                model.numbers[i].Add(new NumberModel() { numberInt = rand1.Next(1, 100), backgroundColour = App.colours[rand1.Next(0, App.colours.Length - 1)] });
                model.numbers[i].Add(new NumberModel() { numberInt = rand2.Next(1, 100), backgroundColour = App.colours[rand2.Next(0, App.colours.Length - 1)] });
                model.numbers[i].Add(new NumberModel() { numberInt = rand3.Next(1, 100), backgroundColour = App.colours[rand3.Next(0, App.colours.Length - 1)] });
            }
            addClickable = false;
            clearClickable = true;
        }

        private void ClearNumbers()
        {
            try
            {
                for (int i = 0; i < 7; i++)
                {
                    model.numbers[i].Clear();
                }
                clearClickable = false;
                addClickable = true;
            }
            catch (Exception ex)
            {
                App.Current.MainPage.DisplayAlert("Exception", ex.Message, "Back");
            }
        }

        private void AddNumbers()
        {
            Random rand1 = new Random();
            Random rand2 = new Random();
            Random rand3 = new Random();

            for (int i = 0; i < 7; i++)
            {
                model.numbers[i].Add(new NumberModel() { numberInt = rand1.Next(1, 100), backgroundColour = App.colours[rand1.Next(0, App.colours.Length - 1)] });
                model.numbers[i].Add(new NumberModel() { numberInt = rand2.Next(1, 100), backgroundColour = App.colours[rand2.Next(0, App.colours.Length - 1)] });
                model.numbers[i].Add(new NumberModel() { numberInt = rand3.Next(1, 100), backgroundColour = App.colours[rand3.Next(0, App.colours.Length - 1)] });
            }
            addClickable = false;
            clearClickable = true;
        }
    }
}
