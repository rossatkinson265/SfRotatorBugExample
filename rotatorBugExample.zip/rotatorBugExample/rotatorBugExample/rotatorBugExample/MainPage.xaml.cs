﻿using rotatorBugExample.ViewModels;
using Syncfusion.SfRotator.XForms;
using Syncfusion.XForms.TabView;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace rotatorBugExample
{
    // Learn more about making custom code visible in the Xamarin.Forms previewer
    // by visiting https://aka.ms/xamarinforms-previewer
    [DesignTimeVisible(false)]
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
            MainViewModel vm = new MainViewModel();
            this.BindingContext = vm;
            Grid contentGrid = new Grid()
            {
                RowDefinitions = new RowDefinitionCollection()
                {
                    new RowDefinition(){ Height = new GridLength(1, GridUnitType.Star)},
                    new RowDefinition(){ Height = new GridLength(1, GridUnitType.Star)},
                    new RowDefinition(){ Height = new GridLength(1, GridUnitType.Star)},
                    new RowDefinition(){ Height = new GridLength(5, GridUnitType.Star)}
                }
            };

            Button updateButton = new Button()
            {
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center,
                CornerRadius = 20,
                Text = "Update Numbers",
                BackgroundColor = Color.Gray,
                TextColor = Color.White
            };
            Button clearButton = new Button()
            {
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center,
                CornerRadius = 20,
                Text = "Clear All Numbers",
                BackgroundColor = Color.Gray,
                TextColor = Color.White
            };
            Button addButton = new Button()
            {
                HorizontalOptions = LayoutOptions.Center,
                VerticalOptions = LayoutOptions.Center,
                CornerRadius = 20,
                Text = "Add All Numbers",
                BackgroundColor = Color.Gray,
                TextColor = Color.White
            };

            SfTabView tabView = new SfTabView()
            {
                HorizontalOptions = LayoutOptions.FillAndExpand,
                VerticalOptions = LayoutOptions.FillAndExpand,
                VisibleHeaderCount = 7,
                EnableSwiping = false
            };

            for (int i = 0; i < 7; i++)
            {
                SfRotator rotator = new SfRotator()
                {
                    HorizontalOptions = LayoutOptions.FillAndExpand,
                    VerticalOptions = LayoutOptions.FillAndExpand,
                    BackgroundColor = Color.Transparent,
                    HeightRequest = App.height * 0.5,
                    WidthRequest = App.width * 0.8
                };
              
                rotator.BindingContext = vm.model.numbers[i];

                rotator.ItemTemplate = new DataTemplate(() =>
                {
                    StackLayout stack = new StackLayout()
                    {
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalOptions = LayoutOptions.Center,
                        Margin = 20,
                        Padding = 10,
                        BackgroundColor = Color.Transparent
                    };

                    Label intLabel = new Label()
                    {
                        VerticalOptions = LayoutOptions.Center,
                        HorizontalOptions = LayoutOptions.Center,
                        VerticalTextAlignment = TextAlignment.Center,
                        HorizontalTextAlignment = TextAlignment.Center,
                        FontSize = 50,
                        TextColor = Color.White
                    };
                    intLabel.SetBinding(Label.TextProperty, "numberInt");
                    intLabel.SetBinding(Label.BackgroundColorProperty, "backgroundColour");
                    stack.Children.Add(intLabel);

                    Button removeButton = new Button()
                    {
                        VerticalOptions = LayoutOptions.Center,
                        HorizontalOptions = LayoutOptions.Center,
                        Text = "Remove from collection",
                        TextColor = Color.White
                    };
                    removeButton.SetBinding(Button.BackgroundColorProperty, "backgroundColour");
                    removeButton.SetBinding(Button.CommandProperty, new Binding("BindingContext.RemoveFromCollection", source: this));
                    removeButton.SetBinding(Button.CommandParameterProperty, "numberInt");
                    stack.Children.Add(removeButton);

                    return stack;
                });

                rotator.SetBinding(SfRotator.ItemsSourceProperty, ".");
                SfTabItem thisItem = new SfTabItem()
                {
                    HeaderContent = new Label() { Text = string.Format("Tab{0}", i), HorizontalTextAlignment = TextAlignment.Center },
                    Content = rotator
                };

                tabView.Items.Add(thisItem);
            }

            updateButton.SetBinding(Button.CommandProperty, "UpdateNumbersCommand");
            clearButton.SetBinding(Button.CommandProperty, "ClearAllCommand");
            clearButton.SetBinding(Button.IsEnabledProperty, "clearClickable");
            addButton.SetBinding(Button.CommandProperty, "AddAllCommand");
            addButton.SetBinding(Button.IsEnabledProperty, "addClickable");
            contentGrid.Children.Add(updateButton, 0, 0);
            contentGrid.Children.Add(clearButton, 0, 1);
            contentGrid.Children.Add(addButton, 0, 2);
            contentGrid.Children.Add(tabView, 0, 3);

            this.Content = contentGrid;

        }
    }
}
