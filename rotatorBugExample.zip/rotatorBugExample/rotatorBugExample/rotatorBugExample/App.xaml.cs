﻿using Syncfusion.Licensing;
using System;
using Xamarin.Essentials;
using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace rotatorBugExample
{
    public partial class App : Application
    {
        public static double height;
        public static double width;
        public static Color[] colours = new Color[]
        {
            Color.Red,
            Color.Green,
            Color.Blue,
            Color.Yellow,
            Color.Orange,
            Color.Purple,
            Color.Brown,
            Color.Pink,
            Color.Gold,
            Color.Silver
        };

        public App()
        {
            MainThread.BeginInvokeOnMainThread(() => { height = DeviceDisplay.MainDisplayInfo.Density == 0 ? DeviceDisplay.MainDisplayInfo.Height : DeviceDisplay.MainDisplayInfo.Height / DeviceDisplay.MainDisplayInfo.Density; });
            MainThread.BeginInvokeOnMainThread(() => { width = DeviceDisplay.MainDisplayInfo.Density == 0 ? DeviceDisplay.MainDisplayInfo.Width : DeviceDisplay.MainDisplayInfo.Width / DeviceDisplay.MainDisplayInfo.Density; });
            SyncfusionLicenseProvider.RegisterLicense("MjU3MDgwQDMxMzgyZTMxMmUzMFlxNitXM0dwZVFqUGkwb21GWlUzNmMxSUhoYTAyUDBUUGxPWWk0VW5zZFE9");
            InitializeComponent();

            MainPage = new MainPage();
        }

        protected override void OnStart()
        {
        }

        protected override void OnSleep()
        {
        }

        protected override void OnResume()
        {
        }
    }
}
