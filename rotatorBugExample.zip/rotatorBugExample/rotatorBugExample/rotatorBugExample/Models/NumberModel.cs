﻿using System;
using System.Collections.Generic;
using System.Text;
using Xamarin.Forms;

namespace rotatorBugExample.Models
{
    public class NumberModel : AbstractModel
    {
        private int _numberInt;
        public int numberInt
        {
            get { return _numberInt; }
            set
            {
                _numberInt = value;
                OnPropertyChanged("numberInt");
            }
        }

        private Color _backgroundColour;
        public Color backgroundColour
        {
            get { return _backgroundColour; }
            set
            {
                _backgroundColour = value;
                OnPropertyChanged("backgroundColour");
            }
        }
    }
}
