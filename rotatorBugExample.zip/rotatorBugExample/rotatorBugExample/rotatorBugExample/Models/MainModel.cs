﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Text;

namespace rotatorBugExample.Models
{
    public class MainModel : AbstractModel
    {
        private ObservableCollection<ObservableCollection<NumberModel>> _numbers = new ObservableCollection<ObservableCollection<NumberModel>>();

        public ObservableCollection<ObservableCollection<NumberModel>> numbers
        {
            get { return _numbers; }
            set
            {
                _numbers = value;
                OnPropertyChanged("numbers");
            }
        }
    }
}
